from petproject import DataController as dc


class DataDemo(object):

    def __init__(self):
        pass

    def main(self):
        dc.DataController().update_view()


DataDemo().main()

# def main():
#    dc.DataController().update_view()
#
# main()
