authorization = 'Bearer fa6bea0d2ebe5948eef6e965424305b30f6aa1c0'
athlet_id = '18042219'
activity_id = '1988930907'
